@extends('admin.base')

@section('title', 'ホーム')
@section('subtitle', 'ホームサブタイトル')
@section('css')

@endsection

@section('content')
<p>ホームです。</p>
@endsection

@section('script')

@endsection
